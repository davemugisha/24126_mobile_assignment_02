import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: CalculatorScreen(),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  @override
  _CalculatorScreenState createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String displayText = '0';
  double num1 = 0;
  double num2 = 0;
  String? operation;
  String result = '';
  String finalResult = '';
  String? prevOperation;

  void buttonPressed(String btnText) {
    if (btnText == 'C') {
      displayText = '0';
      num1 = 0;
      num2 = 0;
      result = '';
      finalResult = '';
      operation = null;
      prevOperation = null;
    } else if (btnText == '+' ||
        btnText == '-' ||
        btnText == '*' ||
        btnText == '/') {
      if (num1 == 0) {
        num1 = double.parse(result);
      } else {
        num2 = double.parse(result);
      }
      if (operation != null) {
        finalResult = calculate();
        num1 = double.parse(finalResult);
        num2 = 0;
      }
      prevOperation = operation;
      operation = btnText;
      result = '';
    } else if (btnText == '=') {
      num2 = double.parse(result);
      finalResult = calculate();
      result = finalResult;
      operation = null;
      num1 = 0;
      num2 = 0;
    } else {
      result = result + btnText;
      finalResult = result;
    }
    setState(() {
      displayText = finalResult;
    });
  }

  String calculate() {
    switch (operation) {
      case '+':
        return (num1 + num2).toString();
      case '-':
        return (num1 - num2).toString();
      case '*':
        return (num1 * num2).toString();
      case '/':
        return (num1 / num2).toString();
      default:
        return result;
    }
  }

  Widget buildButton(String text) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(4.0),
        child: ElevatedButton(
          onPressed: () => buttonPressed(text),
          style: ElevatedButton.styleFrom(
            padding: EdgeInsets.all(20),
            textStyle: TextStyle(fontSize: 24),
          ),
          child: Text(text),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculator'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Expanded(
              child: Container(
                alignment: Alignment.bottomRight,
                child: Text(
                  displayText,
                  style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Divider(),
            Row(
              children: [
                buildButton('7'),
                buildButton('8'),
                buildButton('9'),
                buildButton('/'),
              ],
            ),
            Row(
              children: [
                buildButton('4'),
                buildButton('5'),
                buildButton('6'),
                buildButton('*'),
              ],
            ),
            Row(
              children: [
                buildButton('1'),
                buildButton('2'),
                buildButton('3'),
                buildButton('-'),
              ],
            ),
            Row(
              children: [
                buildButton('0'),
                buildButton('.'),
                buildButton('='),
                buildButton('+'),
              ],
            ),
            Row(
              children: [
                buildButton('C'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
